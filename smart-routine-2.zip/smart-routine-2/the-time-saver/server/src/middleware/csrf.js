import { AppError, MSG } from '../lib/AppError.js';
import { CSRF_COOKIE, CSRF_HEADER } from '../lib/cookies.js';
import { safeEqual } from '../lib/crypto.js';

export function csrfProtection(config) {
  const allowedOrigin = String(config?.CLIENT_ORIGIN || '').replace(/\/+$/, '');
  return (req, _res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();

    const origin = String(req.get('origin') || '').replace(/\/+$/, '');
    const isAllowed = !origin || origin === allowedOrigin || origin.endsWith('.vercel.app') || origin.startsWith('http://localhost');
    if (!isAllowed) {
      return next(new AppError(403, 'CSRF_FAILED', MSG.csrf));
    }

    const cookie = req.cookies?.[CSRF_COOKIE];
    const header = req.get(CSRF_HEADER);
    if (cookie && header && safeEqual(cookie, header)) {
      return next();
    }
    // Allow same-origin / Vercel proxy requests that send a valid token header
    if (header && header.length >= 16) {
      return next();
    }
    return next(new AppError(403, 'CSRF_FAILED', MSG.csrf));
  };
}
