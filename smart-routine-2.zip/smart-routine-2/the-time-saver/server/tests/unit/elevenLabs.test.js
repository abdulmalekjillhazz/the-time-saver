import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  CloudinaryApiError,
  configureCloudinary,
  setCloudinaryClient,
} from '../../src/services/cloudinary.js';
import { audioDramaError, elevenLabsError } from '../../src/routes/speech.js';
import {
  ElevenLabsApiError,
  generateAndUploadLessonAudio,
  generateAndUploadAudioDrama,
  generateElevenLabsAudio,
  parseNarrationSegments,
  resolveNarrationVoice,
} from '../../src/services/elevenLabs.js';
import { hasCompleteStoryScript } from '../../src/services/geminiLessons.js';

const config = {
  ELEVENLABS_API_KEY: 'test-elevenlabs-key',
  ELEVENLABS_MODEL: 'eleven_multilingual_v2',
  ELEVENLABS_FATHER_VOICE_ID: 'father-voice',
  ELEVENLABS_MOTHER_VOICE_ID: 'mother-voice',
  ELEVENLABS_SON_VOICE_ID: 'son-voice',
  ELEVENLABS_STORYTELLER_VOICE_ID: 'storyteller-voice',
  CLOUDINARY_CLOUD_NAME: 'test-cloud',
  CLOUDINARY_API_KEY: 'test-cloud-key',
  CLOUDINARY_API_SECRET: 'test-cloud-secret',
};

afterEach(() => {
  configureCloudinary({});
  vi.unstubAllGlobals();
});

describe('ElevenLabs provider errors', () => {
  it('keeps only the HTTP status and provider error code for safe route mapping', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => ({
      ok: false,
      status: 402,
      json: async () => ({
        detail: {
          status: 'quota_exceeded',
          message: 'Private provider detail should not escape.',
        },
      }),
    })));

    const error = await generateElevenLabsAudio({
      text: 'test',
      speaker: 'father',
      config,
    }).catch((caught) => caught);

    expect(error).toBeInstanceOf(ElevenLabsApiError);
    expect(error).toMatchObject({ status: 402, upstreamCode: 'quota_exceeded' });
    expect(error.message).not.toContain('Private provider detail');
    expect(elevenLabsError(error)).toMatchObject({
      status: 402,
      code: 'PAYMENT_REQUIRED',
      i18n: {
        bn: 'ElevenLabs-এর ব্যবহারযোগ্য credit শেষ। credit যোগ করে আবার চেষ্টা করুন।',
      },
    });
    expect(elevenLabsError(new ElevenLabsApiError(429, 'rate_limit_exceeded'))).toMatchObject({
      status: 429,
      code: 'RATE_LIMITED',
    });
  });

  it('reports rejected Cloudinary credentials before making any paid TTS request', async () => {
    configureCloudinary(config);
    setCloudinaryClient({
      resourceInfo: vi.fn(async () => {
        throw new CloudinaryApiError('lookup', 401);
      }),
      uploadBuffer: vi.fn(),
    });
    const providerRequest = vi.fn();
    vi.stubGlobal('fetch', providerRequest);

    const error = await generateAndUploadAudioDrama({
      content: '[Storyteller]: The story begins.',
      config,
    }).catch((caught) => caught);

    expect(error).toBeInstanceOf(CloudinaryApiError);
    expect(audioDramaError(error)).toMatchObject({
      status: 502,
      code: 'CLOUDINARY_UNAVAILABLE',
      i18n: {
        en: expect.stringContaining('Cloudinary rejected its credentials'),
      },
    });
    expect(providerRequest).not.toHaveBeenCalled();
  });
});

describe('Daily lesson narration', () => {
  it('parses family speakers into ordered narration segments', () => {
    expect(parseNarrationSegments([
      '[Rahim - Father]: First line.',
      '[Asha - Mother]: Second line.',
      '[Rafi - Child]: Third line.',
      '[Storyteller]: Closing line.',
    ].join('\n')).map(({ speaker, text }) => ({ speaker, text }))).toEqual([
      { speaker: 'father', text: 'First line.' },
      { speaker: 'mother', text: 'Second line.' },
      { speaker: 'son', text: 'Third line.' },
      { speaker: 'storyteller', text: 'Closing line.' },
    ]);
  });

  it('routes storyteller and Bengali storyteller tags to the dedicated voice', () => {
    expect(resolveNarrationVoice(config, 'Storyteller')).toBe('storyteller-voice');
    expect(resolveNarrationVoice(config, 'গল্পকথক')).toBe('storyteller-voice');
    expect(resolveNarrationVoice({ ...config, ELEVENLABS_MOTHER_VOICE_ID: undefined }, 'mother')).toBeNull();
    expect(resolveNarrationVoice({ ...config, ELEVENLABS_STORYTELLER_VOICE_ID: undefined }, 'storyteller')).toBeNull();
  });

  it('adds Bengali storyteller framing when narrating an older saved story', () => {
    expect(parseNarrationSegments('[Rahim - Father]: চলুন শুরু করি।').map(({ speaker, text }) => ({ speaker, text }))).toEqual([
      { speaker: 'storyteller', text: 'গল্পটি শুরু হচ্ছে।' },
      { speaker: 'father', text: 'চলুন শুরু করি।' },
      { speaker: 'storyteller', text: 'এরপর তারা একসঙ্গে সমাধান খুঁজতে থাকে।' },
      { speaker: 'storyteller', text: 'এই ছিল আজকের গল্প।' },
    ]);
  });

  it('requires a storyteller opening, middle transition, and closing in generated scripts', () => {
    const complete = [
      '[Storyteller]: গল্প শুরু।',
      '[Rahim - Father]: প্রথম কথা।',
      '[Asha - Mother]: দ্বিতীয় কথা।',
      '[Storyteller]: মাঝের কথা।',
      '[Rafi - Child]: তৃতীয় কথা।',
      '[Storyteller]: গল্প শেষ।',
    ].join('\n');
    expect(hasCompleteStoryScript(complete)).toBe(true);
    expect(hasCompleteStoryScript(complete.replace('[Storyteller]: মাঝের কথা।\n', ''))).toBe(false);
  });

  it('uploads generated narration once and returns the Cloudinary URL', async () => {
    const uploadBuffer = vi.fn(async ({ buffer, publicId }) => ({
      secure_url: 'https://media.example/family-story.mp3',
      public_id: `smart-routine/daily-lessons/${publicId}`,
      bytes: buffer.length,
    }));
    configureCloudinary(config);
    setCloudinaryClient({
      resourceInfo: vi.fn(async () => null),
      uploadBuffer,
    });
    vi.stubGlobal('fetch', vi.fn(async () => ({
      ok: true,
      arrayBuffer: async () => Uint8Array.from([1, 2, 3]).buffer,
    })));

    const audio = await generateAndUploadLessonAudio({
      lesson: {
        slug: 'family-focus',
        content: '[Storyteller]: The story begins.\n[Rahim - Father]: Start small.\n[Asha - Mother]: Keep going.',
      },
      config,
    });

    expect(audio).toMatchObject({
      status: 'ready',
      url: 'https://media.example/family-story.mp3',
      publicId: expect.stringMatching(/^smart-routine\/daily-lessons\/family-focus-[a-f0-9]{20}$/),
    });
    expect(fetch).toHaveBeenCalledTimes(3);
    expect(uploadBuffer).toHaveBeenCalledTimes(1);
    expect(uploadBuffer.mock.calls[0][0].buffer).toEqual(Buffer.from([1, 2, 3, 1, 2, 3, 1, 2, 3]));
  });

  it('reuses an existing Cloudinary asset without calling ElevenLabs again', async () => {
    const resourceInfo = vi.fn(async () => ({
      secure_url: 'https://media.example/already-generated.mp3',
      public_id: 'smart-routine/daily-lessons/family-focus-existing',
      duration: 42,
    }));
    configureCloudinary(config);
    setCloudinaryClient({
      resourceInfo,
      uploadBuffer: vi.fn(),
    });
    const providerRequest = vi.fn();
    vi.stubGlobal('fetch', providerRequest);

    const audio = await generateAndUploadLessonAudio({
      lesson: { slug: 'family-focus', content: '[Rahim - Father]: Keep it simple.' },
      config,
    });

    expect(audio).toMatchObject({
      status: 'ready',
      url: 'https://media.example/already-generated.mp3',
      publicId: 'smart-routine/daily-lessons/family-focus-existing',
      durationSeconds: 42,
    });
    expect(resourceInfo).toHaveBeenCalledOnce();
    expect(providerRequest).not.toHaveBeenCalled();
  });

  it('generates, saves, and reuses a full audio drama and its playable segments', async () => {
    configureCloudinary(config);
    const assets = new Map();
    const uploadBuffer = vi.fn(async ({ buffer, publicId, folder }) => {
      const asset = { secure_url: `https://media.example/${publicId}.mp3`, bytes: buffer.length };
      assets.set(`${folder}/${publicId}`, asset);
      return asset;
    });
    const resourceInfo = vi.fn(async (publicId) => assets.get(publicId) || null);
    setCloudinaryClient({ resourceInfo, uploadBuffer });
    const providerRequest = vi.fn(async () => ({
      ok: true,
      arrayBuffer: async () => Uint8Array.from([1, 2, 3]).buffer,
    }));
    vi.stubGlobal('fetch', providerRequest);
    const content = [
      '[Storyteller]: গল্প শুরু।',
      '[Father]: বাবা বলল।',
      '[Storyteller]: এরপর তারা কথা বলল।',
      '[Mother]: মা বলল।',
      '[Storyteller]: গল্প শেষ।',
    ].join('\n');

    const first = await generateAndUploadAudioDrama({ content, config });

    expect(first).toMatchObject({
      url: expect.stringMatching(/^https:\/\/media\.example\/drama-[a-f0-9]{24}\.mp3$/),
      cached: false,
      segments: [
        { speaker: 'storyteller', text: 'গল্প শুরু।' },
        { speaker: 'father', text: 'বাবা বলল।' },
        { speaker: 'storyteller', text: 'এরপর তারা কথা বলল।' },
        { speaker: 'mother', text: 'মা বলল।' },
        { speaker: 'storyteller', text: 'গল্প শেষ।' },
      ],
    });
    expect(first.segments.every(({ url }) => url.startsWith('https://media.example/'))).toBe(true);
    expect(providerRequest).toHaveBeenCalledTimes(5);
    expect(uploadBuffer).toHaveBeenCalledTimes(6);

    const second = await generateAndUploadAudioDrama({ content, config });

    expect(second).toMatchObject({ url: first.url, cached: true, segments: first.segments });
    expect(providerRequest).toHaveBeenCalledTimes(5);
    expect(uploadBuffer).toHaveBeenCalledTimes(6);
  });

});
